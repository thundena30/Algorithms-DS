/*Pratyusha Thundena
Homework 2
September 5, 2018
*/


import java.io.File;
import java.util.Scanner;
import java.util.Arrays;
import java.io.FileNotFoundException;

public class insertionSort {

public static void insertionSort(double array[]) {  
        int n = array.length;
        // declare array length  
        for (int j = 1; j < n; j++) {
        // intialize the loop to sort   
            double key = array[j];  
            int i = j-1;  
            while ( (i > -1) && ( array [i] > key ) ) {  
                array [i+1] = array [i];  
                i--;  
            }  
            array[i+1] = key;  
            //the first element is given the smallest value
        }  
    }
    
public static void main(String[] args) throws FileNotFoundException{
Scanner in = new Scanner(System.in);
String Filename[]= new String[]{"input_100.txt","input_1000.txt", "input_5000.txt","input_10000.txt", "input_50000.txt", "input_100000.txt", "input_500000.txt"};
//save filenames in a variable
double times[]=new double[Filename.length];
for(int n=0; n<Filename.length;n++)
{
Scanner number = new Scanner(new File(Filename[n]));
long beginTime,finishTime,totalTime;
// declare variables to save time
int mySum = 0;

while (number.hasNextDouble()) {
double x=number.nextDouble();
// save values from file
mySum++;
//increments the value by 1 for each new value
}
number.close();
//close the scanner
double [] arr = new double[mySum];
//initialize an array with "mySum" elements
number = new Scanner (new File(Filename[n]));
for(int i=0; i < mySum; ++i)
arr[i]= number.nextDouble();
number.close();
beginTime = System.nanoTime();
insertionSort(arr);
// runs insertion sort algorithm
finishTime = System.nanoTime();
totalTime = finishTime - beginTime;
// finds exact time taken to run algorithm 
times[n]=totalTime;
System.out.println("Recorded time : "+times[n]+" nanosecond to sort file "+Filename[n]);
// displays the results to the user
}
}      

}
